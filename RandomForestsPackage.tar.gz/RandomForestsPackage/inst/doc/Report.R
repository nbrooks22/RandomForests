## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)
options(tibble.print_min = 10L, tibble.print_max = 10L)

## ----setup--------------------------------------------------------------------
library(RandomForestsPackage)
library(tidyverse)
library(rlang)
set.seed(10)

## -----------------------------------------------------------------------------
X <- runif(50,0,1)
e <- rnorm(50,0,0.2)
Y <- sin(2*pi*X) + e
data_reg <- tibble(x = X, y = Y)
data_reg2 <- list(x = matrix(X, nrow = 1), y = Y)

## -----------------------------------------------------------------------------
X1 <- runif(50,0,1)
X2 <- runif(50,0,1)
e1 <- rnorm(50,0,0.2)
kappa <- function(x,y) y - 0.5 - 0.3*sin(2*pi*x)
f <- function(x,y,e){
  Y <- c()
  for(i in seq_along(x)){
    if(kappa(X1[i],X2[i]) - e[i] <= 0){
      Y[i] <- 1
    } else{
      Y[i] <- 2
    }
  }
  Y
}
data_class <- tibble(x1 = X1, x2 = X2, y = f(X1,X2,e1))
data_class2 <- list(x = matrix(c(X1,X2),nrow = 2, byrow = TRUE), y = f(X1,X2,e1))

## -----------------------------------------------------------------------------
data <- greedy_cart(x = x, y = y, data = data_reg, type = "reg")

## -----------------------------------------------------------------------------
data$tree
data$values
data$dim

## ---- eval = FALSE------------------------------------------------------------
#  greedy_cart(x = x, y = y, data = data_reg, type = "reg", num_leaf = 10)

## ---- eval = FALSE------------------------------------------------------------
#  greedy_cart(x = x, y = y, data = data_reg, type = "reg", depth = 2)

## -----------------------------------------------------------------------------
data_1 <- greedy_cart(x = x, y = y, data = data_reg, type = "reg", num_split = 10)

## ---- eval = FALSE------------------------------------------------------------
#  greedy_cart(x = x, y = y, data = data_reg, type = "reg", min_num = 5)

## ---- fig.height= 5, fig.width=7----------------------------------------------
plotTree(data_1)

## ---- warning = FALSE, fig.height= 5, fig.width=7-----------------------------
printRegression(data_1, "Regression")

## -----------------------------------------------------------------------------
val <- greedy_cart(x = c(x1, x2), y = y, data = data_class, type = "class", depth = 3)
val$tree

## -----------------------------------------------------------------------------
tree <- greedy_cart(x = c(x1,x2), y = y, data = data_class, type = "class", unique = TRUE)

## ---- fig.height= 5, fig.width=7----------------------------------------------
printClassification(tree, "Klassifikation")

## -----------------------------------------------------------------------------
lambda <- 1/100
pruning(data$tree,lambda,type="reg")

## -----------------------------------------------------------------------------
Lambda <- c(1,2)/100
cross_validation(data_reg2, Lambda, m=2, type="reg")

## ---- warning = FALSE---------------------------------------------------------
data <- bagging(data = data_reg2, b = 3, type = "reg")

## -----------------------------------------------------------------------------
data$Bagged_Trees
data$Prediction

## -----------------------------------------------------------------------------
pred_matrix <- matrix(c(0.3, 0.5, 1), ncol = 3)
data <- bagging(data = data_reg2, type = "reg", pred_val = pred_matrix)
data$Prediction

## ---- eval = FALSE------------------------------------------------------------
#  bagging(data = data_class2, b = 8, type = "class")

## -----------------------------------------------------------------------------
random_forest(x = c(x1,x2), y = y, data = data_class, type = "class", B = 5, A = 25, m = 1, num_leaf = 15)

## -----------------------------------------------------------------------------
treelist <- bagging(data = data_reg2, b = 3, type = "reg")
xlist <- matrix(c(0, 0.25, 0.5, 1), nrow = 1)
make_prediction(treelist$Bagged_Trees, xlist, type = "reg")

